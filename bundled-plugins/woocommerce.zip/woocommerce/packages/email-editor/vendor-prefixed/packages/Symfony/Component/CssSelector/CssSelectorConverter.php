<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector;

use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\Parser\Shortcut\ClassParser;
use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\Parser\Shortcut\ElementParser;
use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\Parser\Shortcut\EmptyStringParser;
use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\Parser\Shortcut\HashParser;
use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\XPath\Extension\HtmlExtension;
use Automattic\WooCommerce\EmailEditorVendor\Symfony\Component\CssSelector\XPath\Translator;

/**
 * CssSelectorConverter is the main entry point of the component and can convert CSS
 * selectors to XPath expressions.
 *
 * @author Christophe Coevoet <stof@notk.org>
 */
class CssSelectorConverter
{
    private $translator;
    private $cache;

    /**
     * Maximum number of cached items per prefix before LRU eviction kicks in.
     *
     * @var int
     */
    public static $maxCachedItems = 200;

    private static $xmlCache = [];
    private static $htmlCache = [];

    /**
     * @param bool $html Whether HTML support should be enabled. Disable it for XML documents
     */
    public function __construct(bool $html = true)
    {
        $this->translator = new Translator();

        if ($html) {
            $this->translator->registerExtension(new HtmlExtension($this->translator));
            $this->cache = &self::$htmlCache;
        } else {
            $this->cache = &self::$xmlCache;
        }

        $this->translator
            ->registerParserShortcut(new EmptyStringParser())
            ->registerParserShortcut(new ElementParser())
            ->registerParserShortcut(new ClassParser())
            ->registerParserShortcut(new HashParser())
        ;
    }

    /**
     * Translates a CSS expression to its XPath equivalent.
     *
     * Optionally, a prefix can be added to the resulting XPath
     * expression with the $prefix parameter.
     *
     * @return string
     */
    public function toXPath(string $cssExpr, string $prefix = 'descendant-or-self::')
    {
        if (isset($this->cache[$prefix][$cssExpr])) {
            // Promote to most-recently-used position.
            $value = $this->cache[$prefix][$cssExpr];
            unset($this->cache[$prefix][$cssExpr]);

            return $this->cache[$prefix][$cssExpr] = $value;
        }

        $value = $this->translator->cssToXPath($cssExpr, $prefix);

        if (\count($this->cache[$prefix] ?? []) >= self::$maxCachedItems) {
            // Evict least-recently-used entry.
            unset($this->cache[$prefix][\array_key_first($this->cache[$prefix])]);
        }

        return $this->cache[$prefix][$cssExpr] = $value;
    }
}
