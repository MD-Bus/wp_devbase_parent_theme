<?php
/**
 * File for WC Variable Product Data Store class.
 *
 * @package WooCommerce\Classes
 */

use Automattic\WooCommerce\Enums\ProductStatus;
use Automattic\WooCommerce\Enums\ProductStockStatus;
use Automattic\WooCommerce\Enums\TaxDisplayMode;
use Automattic\WooCommerce\Internal\Caches\ProductVersionStringInvalidator;
use Automattic\WooCommerce\Internal\Utilities\ProductUtil;
use Automattic\WooCommerce\Utilities\CallbackUtil;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC Variable Product Data Store: Stored in CPT.
 *
 * @version 3.0.0
 */
class WC_Product_Variable_Data_Store_CPT extends WC_Product_Data_Store_CPT implements WC_Object_Data_Store_Interface, WC_Product_Variable_Data_Store_Interface {

	/**
	 * Cached & hashed prices array for child variations.
	 *
	 * @var array
	 */
	protected $prices_array = array();

	/**
	 * Read attributes from post meta.
	 *
	 * @param WC_Product $product Product object.
	 */
	protected function read_attributes( &$product ) {
		$product_id      = $product->get_id();
		$meta_attributes = get_post_meta( $product_id, '_product_attributes', true );

		if ( ! empty( $meta_attributes ) && is_array( $meta_attributes ) ) {
			$attributes   = array();
			$force_update = false;
			foreach ( $meta_attributes as $meta_attribute_key => $meta_attribute_value ) {
				$meta_value = array_merge(
					array(
						'name'         => '',
						'value'        => '',
						'position'     => 0,
						'is_visible'   => 0,
						'is_variation' => 0,
						'is_taxonomy'  => 0,
					),
					(array) $meta_attribute_value
				);

				// Maintain data integrity: WordPress 4.9 changed sanitization functions, and we update the values here so variations function correctly.
				// Since 10.6.0, we are refactoring the updates into product-level: BC-focused (not all-in on-spot migration), optimized for performance.
				// Use-case: `_product_attributes` has data populated on WordPress pre-4.8 and containing symbols affected by the breaking changes.
				if ( $meta_value['is_variation'] && strstr( $meta_value['name'], '/' ) && sanitize_title( $meta_value['name'] ) !== $meta_attribute_key ) {
					global $wpdb;

					$child_ids = $product->get_children();
					if ( ! empty( $child_ids ) ) {
						$products_to_migrate = implode( ', ', $child_ids );
						$old_slug            = 'attribute_' . $meta_attribute_key;
						$old_meta_rows       = $wpdb->get_results(
							$wpdb->prepare(
								// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
								"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ( $products_to_migrate )",
								$old_slug
							)
						);
						if ( $old_meta_rows ) {
							$new_slug = 'attribute_' . sanitize_title( $meta_value['name'] );
							foreach ( $old_meta_rows as $old_meta_row ) {
								update_post_meta( $old_meta_row->post_id, $new_slug, $old_meta_row->meta_value );
							}
						}
					}

					$force_update = true;
				}

				// Check if is a taxonomy attribute.
				if ( ! empty( $meta_value['is_taxonomy'] ) ) {
					if ( ! taxonomy_exists( $meta_value['name'] ) ) {
						continue;
					}
					// Performance note: at this stage, the product factory has already primed the caches, so wc_get_object_terms does not present a concern.
					$id      = wc_attribute_taxonomy_id_by_name( $meta_value['name'] );
					$options = wc_get_object_terms( $product_id, $meta_value['name'], 'term_id' );
				} else {
					$id      = 0;
					$options = wc_get_text_attributes( $meta_value['value'] );
				}

				$attribute = new WC_Product_Attribute();
				$attribute->set_id( $id );
				$attribute->set_name( $meta_value['name'] );
				$attribute->set_options( $options );
				$attribute->set_position( $meta_value['position'] );
				$attribute->set_visible( $meta_value['is_visible'] );
				$attribute->set_variation( $meta_value['is_variation'] );

				/**
				 * Filter product attribute after initialization.
				 *
				 * @since 10.6.0
				 *
				 * @param WC_Product_Attribute $attribute  The attribute object.
				 * @param array                $meta_value The meta value.
				 * @param WC_Product           $product    The product object.
				 */
				$attributes[] = apply_filters( 'woocommerce_product_read_attribute', $attribute, $meta_value, $product );
			}
			$product->set_attributes( $attributes );

			if ( $force_update ) {
				$this->update_attributes( $product, true );
			}
		}
	}

	/**
	 * Read product data.
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since 3.0.0
	 */
	protected function read_product_data( &$product ) {
		// Prime caches to reduce future queries.
		if ( ! wp_using_ext_object_cache() ) {
			$product_id = $product->get_id();
			wp_prime_option_caches(
				array(
					// Transients from \WC_Product_Variable_Data_Store_CPT class.
					'_transient_wc_var_prices_' . $product_id,
					'_transient_timeout_wc_var_prices_' . $product_id,
					'_transient_wc_product_children_' . $product_id,
					'_transient_timeout_wc_product_children_' . $product_id,
					// Transients from \WC_Product_Variable class.
					'_transient_wc_child_has_weight_' . $product_id,
					'_transient_timeout_wc_child_has_weight_' . $product_id,
					'_transient_wc_child_has_dimensions_' . $product_id,
					'_transient_timeout_wc_child_has_dimensions_' . $product_id,
					// Transients from \wc_get_related_products function.
					'_transient_wc_related_' . $product_id,
					'_transient_timeout_wc_related_' . $product_id,
				)
			);
		}

		parent::read_product_data( $product );

		// Make sure data which does not apply to variables is unset.
		$product->set_regular_price( '' );
		$product->set_sale_price( '' );
	}

	/**
	 * Loads variation child IDs.
	 *
	 * @param WC_Product $product Product object.
	 * @param bool       $force_read True to bypass the transient.
	 *
	 * @return array
	 */
	public function read_children( &$product, $force_read = false ) {
		$children_transient_name = 'wc_product_children_' . $product->get_id();
		$children                = get_transient( $children_transient_name );
		if ( empty( $children ) || ! is_array( $children ) ) {
			$children = array();
		}

		$transient_version = WC_Cache_Helper::get_transient_version( 'product' );

		if ( ! $force_read && $children ) {
			// Validate the children data.
			if ( ! $this->validate_children_data( $children, $transient_version ) ) {
				$children   = array();
				$force_read = true;
			}
		}

		if ( ! isset( $children['all'] ) || ! isset( $children['visible'] ) || $force_read ) {
			$all_args = array(
				'post_parent' => $product->get_id(),
				'post_type'   => 'product_variation',
				'orderby'     => array(
					'menu_order' => 'ASC',
					'ID'         => 'ASC',
				),
				'fields'      => 'ids',
				'post_status' => array( ProductStatus::PUBLISH, ProductStatus::PRIVATE ),
				'numberposts' => -1, // phpcs:ignore WordPress.VIP.PostsPerPage.posts_per_page_numberposts
			);

			$visible_only_args                = $all_args;
			$visible_only_args['post_status'] = ProductStatus::PUBLISH;

			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				$visible_only_args['tax_query'][] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => ProductStockStatus::OUT_OF_STOCK,
					'operator' => 'NOT IN',
				);
			}

			/**
			 * Filters the query arguments used to retrieve variation children of a variable product.
			 *
			 * @since 3.0.0
			 *
			 * @param array      $args            Query arguments for get_posts().
			 * @param WC_Product $product         The variable product object.
			 * @param bool       $visible_only    True when retrieving only visible variations, false for all variations.
			 */
			$children['all'] = get_posts( apply_filters( 'woocommerce_variable_children_args', $all_args, $product, false ) );

			// phpcs:disable WooCommerce.Commenting.CommentHooks
			$children['visible'] = get_posts( apply_filters( 'woocommerce_variable_children_args', $visible_only_args, $product, true ) );

			// Validate the children data before storing it in the transient.
			if ( $this->validate_children_data( $children, $transient_version ) ) {
				set_transient( $children_transient_name, $children, DAY_IN_SECONDS * 30 );
			}
		}

		$children['all']     = wp_parse_id_list( (array) $children['all'] );
		$children['visible'] = wp_parse_id_list( (array) $children['visible'] );

		return $children;
	}

	/**
	 * Loads an array of attributes used for variations, as well as their possible values.
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @return array
	 */
	public function read_variation_attributes( &$product ) {
		global $wpdb;

		$product_id  = $product->get_id();
		$cache_key   = WC_Cache_Helper::get_cache_prefix( 'product_' . $product_id ) . 'product_variation_attributes_' . $product_id;
		$cached_data = wp_cache_get( $cache_key, 'products' );

		if ( false !== $cached_data ) {
			return $cached_data;
		}

		$variation_attributes = array();
		$attributes           = $product->get_attributes();

		if ( ! empty( $attributes ) ) {
			$child_ids  = $product->get_children();
			$attributes = array_values( array_filter( $attributes, static fn ( $attribute ) => ! empty( $attribute['is_variation'] ) ) );

			$attributes_values = array();
			if ( ! empty( $child_ids ) && ! empty( $attributes ) ) {
				// Performance note: for optimal performance, retrieve attribute values using a single SQL query.
				$attributes_placeholders = implode( ', ', array_fill( 0, count( $attributes ), '%s' ) );
				$children_placeholders   = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
				$prefetch                = $wpdb->get_results(
					$wpdb->prepare(
						// Performance: DISTINCT + CAST(meta_value AS BINARY(200)) is feasible but forces a temp table — keep array_unique.
						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
						"SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ( {$children_placeholders} ) AND meta_key IN ( {$attributes_placeholders} )",
						...$child_ids,
						...array_map( static fn( $attribute ) => wc_variation_attribute_name( $attribute['name'] ), $attributes )
					)
				);
				foreach ( $prefetch as $row ) {
					// Defensive: normalize non-canonical meta_key casing (e.g. attribute_pa_Size → attribute_pa_size).
					// sanitize_title over wc_variation_attribute_name as the latter adds 'attribute_' prefix.
					$attributes_values[ sanitize_title( $row->meta_key ) ][] = $row->meta_value;
				}
			}

			foreach ( $attributes as $attribute ) {
				$values = $attributes_values[ wc_variation_attribute_name( $attribute['name'] ) ] ?? array();

				// Empty value indicates that all options for given attribute are available.
				if ( empty( $values ) || in_array( null, $values, true ) || in_array( '', $values, true ) ) {
					$values = $attribute['is_taxonomy'] ? wc_get_object_terms( $product_id, $attribute['name'], 'slug' ) : wc_get_text_attributes( $attribute['value'] );
					// Get custom attributes (non taxonomy) as defined.
				} elseif ( ! $attribute['is_taxonomy'] ) {
					$text_attributes          = wc_get_text_attributes( $attribute['value'] );
					$assigned_text_attributes = $values;
					$values                   = array();

					// Pre 2.4 handling where 'slugs' were saved instead of the full text attribute.
					if ( version_compare( get_post_meta( $product_id, '_product_version', true ), '2.4.0', '<' ) ) {
						$assigned_text_attributes = array_map( 'sanitize_title', $assigned_text_attributes );
						foreach ( $text_attributes as $text_attribute ) {
							if ( in_array( sanitize_title( $text_attribute ), $assigned_text_attributes, true ) ) {
								$values[] = $text_attribute;
							}
						}
					} else {
						foreach ( $text_attributes as $text_attribute ) {
							if ( in_array( $text_attribute, $assigned_text_attributes, true ) ) {
								$values[] = $text_attribute;
							}
						}
					}
				}
				$variation_attributes[ $attribute['name'] ] = array_unique( $values );
			}
		}

		wp_cache_set( $cache_key, $variation_attributes, 'products' );

		return $variation_attributes;
	}

	/**
	 * Get an array of all sale and regular prices from all variations. This is used for example when displaying the price range at variable product level or seeing if the variable product is on sale.
	 *
	 * Can be filtered by plugins which modify costs, but otherwise will include the raw meta costs unlike get_price() which runs costs through the woocommerce_get_price filter.
	 * This is to ensure modified prices are not cached, unless intended.
	 *
	 * @param WC_Product $product Product object.
	 * @param bool       $for_display If true, prices will be adapted for display based on the `woocommerce_tax_display_shop` setting (including or excluding taxes).
	 *
	 * @return array of prices
	 * @since  3.0.0
	 */
	public function read_price_data( &$product, $for_display = false ) {
		/**
		 * If you are here to investigate performance of this method: yes, it is heavy in RAM and CPU usage overall.
		 *
		 * The root cause is that variation object usage is hard-locked by multiple contracts (extension points / filters).
		 * Those contracts are heavily used by popular extensions, rendering most optimization routes irrelevant at scale.
		 *
		 * Optimizations already in place:
		 * - request-level cache ($this->prices_array)
		 * - cross-request cache (transient wc_var_prices_<product_id>; sensitive to product transient invalidation through multiple workflows)
		 * - cache priming (bulk-fetching data from DB) for the product and its variations
		 * - object instance caching (request-level optimization for wc_get_product; applies across Woo core and extensions)
		 * - capping the transient size so it doesn't grow unbounded over the 30-day retention period
		 *
		 * That leaves single optimization route:
		 * - rewrite this method, if breaking the contracts is an option (it's not as per WooCommerce v11.1)
		 */
		$price_hash = $this->get_price_hash( $product, $for_display );
		if ( empty( $this->prices_array[ $price_hash ] ) ) {
			/**
			 * Transient name for storing prices for this product (note: Max transient length is 45)
			 *
			 * @since 2.5.0 a single transient is used per product for all prices, rather than many transients per product.
			 */
			$transient_name      = 'wc_var_prices_' . $product->get_id();
			$transient_version   = WC_Cache_Helper::get_transient_version( 'product' );
			$opposite_price_hash = $this->taxes_influence_price( $product ) ? null : $this->get_price_hash( $product, ! $for_display );

			// If the prices are not valid, reset the transient cache.
			$transient_cached_prices_array = array_filter( (array) json_decode( (string) get_transient( $transient_name ), true ) );
			if ( ! $this->validate_prices_data( $transient_cached_prices_array, $transient_version ) ) {
				$transient_cached_prices_array = array();
			}

			// If the prices are not stored for this hash, generate them and add to the transient.
			// Check also the opposite price hash as it may have changed (see get_price_hash).
			if ( empty( $transient_cached_prices_array[ $price_hash ] ) || ( null !== $opposite_price_hash && empty( $transient_cached_prices_array[ $opposite_price_hash ] ) ) ) {
				$prices_array = array(
					'price'         => array(),
					'regular_price' => array(),
					'sale_price'    => array(),
				);

				$variation_ids = $product->get_visible_children();

				if ( ! empty( $variation_ids ) ) {
					// Prime caches to reduce future queries.
					_prime_post_caches( $variation_ids );
				}

				$tax_display_mode = $for_display ? get_option( 'woocommerce_tax_display_shop' ) : null;
				$price_decimals   = wc_get_price_decimals();
				foreach ( $variation_ids as $variation_id ) {
					$variation = wc_get_product( $variation_id );

					if ( $variation ) {
						/**
						 * Filters the active price for a product variation before it is used in price calculations and caching.
						 *
						 * IMPORTANT: If your filter returns a price that varies by ANY factor (e.g., current user,
						 * time of day, user role, cart contents, etc.), you MUST also hook into the
						 * 'woocommerce_get_variation_prices_hash' filter to include that factor in the cache key.
						 * Otherwise, the wrong price may be cached and displayed to different users or contexts.
						 *
						 * Example: Applying a per-user discount and adapting the price hash info accordingly:
						 *
						 * class My_Custom_Pricing {
						 *     public function __construct() {
						 *         add_filter( 'woocommerce_variation_prices_price', array( $this, 'apply_user_discount' ), 10, 3 );
						 *         add_filter( 'woocommerce_get_variation_prices_hash', array( $this, 'add_user_to_hash' ), 10, 3 );
						 *     }
						 *
						 *     public function apply_user_discount( $price, $variation, $product ) {
						 *         return wc_format_decimal( $price * $this->get_discount_for_user( get_current_user_id() ), wc_get_price_decimals() );
						 *     }
						 *
						 *     public function add_user_to_hash( $price_hash, $product, $for_display ) {
						 *         $price_hash[] = get_current_user_id();
						 *         return $price_hash;
						 *     }
						 * }
						 *
						 * @since 3.0.0
						 *
						 * @param string        $price    The variation's active price.
						 * @param WC_Product    $variation The variation product object.
						 * @param WC_Product    $product   The parent variable product object.
						 */
						$price = apply_filters( 'woocommerce_variation_prices_price', $variation->get_price( 'edit' ), $variation, $product );

						// Skip empty prices.
						if ( '' === $price ) {
							continue;
						}

						/**
						 * Filters the regular price for a product variation before it is used in price calculations and caching.
						 *
						 * IMPORTANT: see the documentation for the 'woocommerce_variation_prices_price' filter.
						 *
						 * @since 3.0.0
						 *
						 * @param string        $regular_price The variation's regular price.
						 * @param WC_Product    $variation     The variation product object.
						 * @param WC_Product    $product       The parent variable product object.
						 */
						$regular_price = apply_filters( 'woocommerce_variation_prices_regular_price', $variation->get_regular_price( 'edit' ), $variation, $product );

						/**
						 * Filters the sale price for a product variation before it is used in price calculations and caching.
						 *
						 * IMPORTANT: see the documentation for the 'woocommerce_variation_prices_price' filter.
						 *
						 * @since 3.0.0
						 *
						 * @param string        $sale_price The variation's sale price.
						 * @param WC_Product    $variation  The variation product object.
						 * @param WC_Product    $product    The parent variable product object.
						 */
						$sale_price = apply_filters( 'woocommerce_variation_prices_sale_price', $variation->get_sale_price( 'edit' ), $variation, $product );

						// If sale price does not equal price, the product is not yet on sale.
						if ( $sale_price === $regular_price || $sale_price !== $price ) {
							$sale_price = $regular_price;
						}

						// If we are getting prices for display, we need to account for taxes.
						if ( $for_display ) {
							if ( TaxDisplayMode::INCLUSIVE === $tax_display_mode ) {
								$price         = '' === $price ? '' : wc_get_price_including_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $price,
									)
								);
								$regular_price = '' === $regular_price ? '' : wc_get_price_including_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $regular_price,
									)
								);
								$sale_price    = '' === $sale_price ? '' : wc_get_price_including_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $sale_price,
									)
								);
							} else {
								$price         = '' === $price ? '' : wc_get_price_excluding_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $price,
									)
								);
								$regular_price = '' === $regular_price ? '' : wc_get_price_excluding_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $regular_price,
									)
								);
								$sale_price    = '' === $sale_price ? '' : wc_get_price_excluding_tax(
									$variation,
									array(
										'qty'   => 1,
										'price' => $sale_price,
									)
								);
							}
						}

						$prices_array['price'][ $variation_id ]         = wc_format_decimal( $price, $price_decimals );
						$prices_array['regular_price'][ $variation_id ] = wc_format_decimal( $regular_price, $price_decimals );
						$prices_array['sale_price'][ $variation_id ]    = wc_format_decimal( $sale_price, $price_decimals );

						if ( has_filter( 'woocommerce_variation_prices_array' ) ) {
							$original_prices_array = $prices_array;

							/**
							 * Filter the variation prices array before storing in transient cache.
							 *
							 * This filter allows developers to modify the variation prices array for each variation
							 * during the price calculation process. It's called for each variation individually
							 * and can be used to add custom pricing data or modify existing prices.
							 *
							 * @since 3.6.0
							 *
							 * @param array        $prices_array The prices array being built. Contains 'price', 'regular_price', and 'sale_price' keys.
							 * @param WC_Product   $variation    The variation product object.
							 * @param bool         $for_display  Whether prices are for display (with tax adjustments) or for calculations.
							 */
							$prices_array = apply_filters( 'woocommerce_variation_prices_array', $prices_array, $variation, $for_display );
							if ( null !== $opposite_price_hash ) {
								// $for_display doesn't affect raw prices here, but a woocommerce_variation_prices_array hook might.
								// phpcs:ignore WooCommerce.Commenting.CommentHooks
								$opposite_prices_array = apply_filters( 'woocommerce_variation_prices_array', $original_prices_array, $variation, ! $for_display );
								if ( $opposite_prices_array !== $prices_array ) {
									$opposite_price_hash = null;
								}
							}
						}
					}
				}

				// Add all pricing data to the transient array: ensure the hashes always pushed to the end.
				foreach ( array_filter( array( $price_hash, $opposite_price_hash ) ) as $hash ) {
					unset( $transient_cached_prices_array[ $hash ] );
					foreach ( $prices_array as $key => $values ) {
						$transient_cached_prices_array[ $hash ][ $key ] = $values;
					}
				}

				// Validate the prices data before storing it in the transient.
				if ( $this->validate_prices_data( $transient_cached_prices_array, $transient_version ) ) {
					$json = wp_json_encode( $transient_cached_prices_array );

					// Cap the transient size — hash churn (e.g. real-time or role-based pricing) can bloat it over the 30-day TTL.
					// Size-based cap rather than count-based, as the number of variations per hash varies widely.
					// Read-optimized: 8KB keeps the wp_options row inline in InnoDB; 64KB stays within a single Memcached slab.
					$transient_size_cap  = wp_using_ext_object_cache() ? 65536 : 8192;
					$transient_size      = strlen( (string) $json );
					$cached_hashes_count = count( $transient_cached_prices_array );
					if ( $transient_size > $transient_size_cap && $cached_hashes_count > 4 ) {
						$cached_hashes_to_keep         = max( 4, (int) floor( $transient_size_cap / ( $transient_size / $cached_hashes_count ) ) );
						$transient_cached_prices_array = array_slice( $transient_cached_prices_array, -$cached_hashes_to_keep, null, true );
						$json                          = wp_json_encode( $transient_cached_prices_array );
					}

					set_transient( $transient_name, $json, DAY_IN_SECONDS * 30 );
				}
			}

			/**
			 * Filters the variation prices array for a variable product.
			 *
			 * This filter gives plugins one last chance to modify the variation prices array which has been
			 * generated and will be stored locally to the class. This value may differ from the transient cache.
			 * It is filtered once before storing locally.
			 *
			 * @since 3.0.0
			 *
			 * @param array      $prices_array {
			 *     Associative array of variation prices indexed by variation ID.
			 *
			 *     @type array $price         Array of active prices (variation_id => price).
			 *     @type array $regular_price Array of regular prices (variation_id => price).
			 *     @type array $sale_price    Array of sale prices (variation_id => price).
			 * }
			 * @param WC_Product $product      The variable product object.
			 * @param bool       $for_display  Whether prices are being retrieved for display.
			 */
			$this->prices_array[ $price_hash ] = apply_filters( 'woocommerce_variation_prices', $transient_cached_prices_array[ $price_hash ], $product, $for_display );
			if ( $this->prices_array[ $price_hash ] !== $transient_cached_prices_array[ $price_hash ] && ! $this->validate_prices_data( array( $price_hash => $this->prices_array[ $price_hash ] ), $transient_version ) ) {
				wc_doing_it_wrong(
					__METHOD__,
					__( '`woocommerce_variation_prices` returned an unsupported data format. The value is currently used as-is but will be ignored in a future release. Ensure your callback returns the expected array structure.', 'woocommerce' ),
					'11.1'
				);
			}

			if ( null !== $opposite_price_hash && $opposite_price_hash !== $price_hash ) {
				$this->prices_array[ $opposite_price_hash ] = apply_filters( 'woocommerce_variation_prices', $transient_cached_prices_array[ $opposite_price_hash ], $product, ! $for_display );
				if ( $this->prices_array[ $opposite_price_hash ] !== $transient_cached_prices_array[ $opposite_price_hash ] && ! $this->validate_prices_data( array( $opposite_price_hash => $this->prices_array[ $opposite_price_hash ] ), $transient_version ) ) {
					wc_doing_it_wrong(
						__METHOD__,
						__( '`woocommerce_variation_prices` returned an unsupported data format. The value is currently used as-is but will be ignored in a future release. Ensure your callback returns the expected array structure.', 'woocommerce' ),
						'11.1'
					);
				}
			}
		}
		return $this->prices_array[ $price_hash ];
	}

	/**
	 * Check if the prices for a product will be different with or without taxes.
	 *
	 * @param WC_Product $product Product to check.
	 * @return bool True if the prices will be different with or without taxes.
	 *
	 * @since 10.4.0
	 */
	protected function taxes_influence_price( $product ): bool {
		if ( ! $product->is_taxable() ) {
			$taxes_influence_price = false;
		} elseif ( empty( WC_Tax::get_rates( $product->get_tax_class() ) ) ) {
			$taxes_influence_price = false;
		} else {
			// Taxes influence the price regardless of VAT exempt status. Even when a
			// customer is VAT exempt, the displayed prices differ from non-exempt
			// prices, so they need separate cache entries and the opposite_price_hash
			// optimization should not apply. Returning false here was causing cached
			// non-exempt prices to be served to VAT exempt customers.
			$taxes_influence_price = true;
		}

		/**
		 * Filters whether taxes influence the displayed price of a variable product.
		 *
		 * Return `true` from this filter to force separate cache entries for the two
		 * variants. This is needed when an extension produces displayed prices that
		 * differ from raw prices independently of the standard tax calculation, for
		 * example when computing per-country prices for locations that have no
		 * configured tax rates.
		 *
		 * @param bool       $taxes_influence_price Default decision based on product taxability and configured tax rates.
		 * @param WC_Product $product               The variable product being evaluated.
		 *
		 * @since 10.9.0
		 */
		return (bool) apply_filters( 'woocommerce_variable_product_taxes_influence_price', $taxes_influence_price, $product );
	}

	/**
	 * Create unique cache key based on the tax location (affects displayed/cached prices), product version and active price filters.
	 * DEVELOPERS should filter this hash if offering conditional pricing to keep it unique.
	 *
	 * @param WC_Product $product Product object.
	 * @param bool       $for_display If taxes should be calculated or not.
	 *
	 * @since  3.0.0
	 * @return string
	 */
	protected function get_price_hash( &$product, $for_display = false ) {
		$price_hash = array( false );

		if ( $for_display && wc_tax_enabled() ) {
			$price_hash = array(
				get_option( 'woocommerce_tax_display_shop', TaxDisplayMode::EXCLUSIVE ),
				WC_Tax::get_rates(),
				! empty( WC()->customer ) && WC()->customer->is_vat_exempt(),
			);
		}

		$filter_names = array( 'woocommerce_variation_prices_price', 'woocommerce_variation_prices_regular_price', 'woocommerce_variation_prices_sale_price' );

		/**
		 * Filters whether to use the legacy callback serialization algorithm.
		 *
		 * By default, WooCommerce will use the legacy algorithm to get the callback signatures
		 * for variation price hash calculation. That algorithm includes the callback array as it
		 * comes from $wp_filter in the hashed data, which is then JSON encoded. For callbacks that
		 * are class methods, JSON encoding captures the object's PUBLIC property values only;
		 * private and protected properties are not captured. Note that dynamically created
		 * properties are public, and that a class implementing JsonSerializable controls what is
		 * captured through its jsonSerialize() method. A change in any captured value will change
		 * the price hash, even if it does not affect the price calculation.
		 *
		 * This filter allows using CallbackUtil instead, which generates a more stable signature
		 * that does not depend on the internal state of objects, but only on the method names and
		 * class names. This results in a more consistent and reliable price hash, reducing unnecessary
		 * cache misses; but can cause compatibility issues with plugins that rely on the legacy behavior.
		 *
		 * IMPORTANT: see also the documentation for the 'woocommerce_variation_prices_price' filter.
		 *
		 * @since 10.5.0
		 *
		 * @param bool       $use_legacy  True to use the legacy algorithm (default), false to use CallbackUtil
		 * @param WC_Product $product     The product object.
		 * @param bool       $for_display If taxes should be calculated or not.
		 */
		$use_legacy_algorithm = apply_filters( 'woocommerce_use_legacy_get_variations_price_hash', true, $product, $for_display );

		if ( $use_legacy_algorithm ) {
			global $wp_filter;

			foreach ( $filter_names as $filter_name ) {
				if ( ! empty( $wp_filter[ $filter_name ] ) ) {
					$price_hash[ $filter_name ] = array();

					foreach ( $wp_filter[ $filter_name ] as $priority => $callbacks ) {
						$price_hash[ $filter_name ][] = array_values( wp_list_pluck( $callbacks, 'function' ) );
					}
				}
			}
		} else {
			foreach ( $filter_names as $filter_name ) {
				$signatures = CallbackUtil::get_hook_callback_signatures( $filter_name );
				if ( ! empty( $signatures ) ) {
					$price_hash[ $filter_name ] = $signatures;
				}
			}
		}

		/**
		 * Filters the hash used for caching variation prices.
		 *
		 * IMPORTANT: see the documentation for the 'woocommerce_variation_prices_price' filter.
		 *
		 * @since 2.5.0
		 *
		 * @param array      $price_hash Array of factors used to generate the cache key hash.
		 * @param WC_Product $product     The variable product object.
		 * @param bool       $for_display Whether prices are for display (with tax adjustments) or calculations.
		 */
		$price_hash = apply_filters( 'woocommerce_get_variation_prices_hash', $price_hash, $product, $for_display );

		return md5( wp_json_encode( $price_hash ) );
	}

	/**
	 * Does a child have a weight set?
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since  3.0.0
	 * @return boolean
	 */
	public function child_has_weight( $product ) {
		global $wpdb;

		$has_weight = false;
		$child_ids  = $product->get_visible_children();
		if ( ! empty( $child_ids ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
			$has_weight   = (bool) $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_weight' AND meta_value > 0 AND post_id IN ( {$placeholders} ) LIMIT 1",
					$child_ids
				)
			);
		}

		return $has_weight;
	}

	/**
	 * Does a child have dimensions set?
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since  3.0.0
	 * @return boolean
	 */
	public function child_has_dimensions( $product ) {
		global $wpdb;

		$has_dimensions = false;
		$child_ids      = $product->get_visible_children();
		if ( ! empty( $child_ids ) ) {
			$placeholders   = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
			$has_dimensions = (bool) $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ( '_length', '_width', '_height' ) AND meta_value > 0 AND post_id IN ( {$placeholders} ) LIMIT 1",
					$child_ids
				)
			);
		}

		return $has_dimensions;
	}

	/**
	 * Is a child in stock?
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since  3.0.0
	 * @return boolean
	 */
	public function child_is_in_stock( $product ) {
		return $this->child_has_stock_status( $product, ProductStockStatus::IN_STOCK );
	}

	/**
	 * Does a child have a stock status?
	 *
	 * @param WC_Product $product Product object.
	 * @param string     $status 'instock', 'outofstock', or 'onbackorder'.
	 *
	 * @since  3.3.0
	 * @return boolean
	 */
	public function child_has_stock_status( $product, $status ) {
		global $wpdb;

		$has_matches = false;
		$child_ids   = $product->get_children();
		if ( ! empty( $child_ids ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
			if ( get_option( 'woocommerce_product_lookup_table_is_generating' ) ) {
				$query = "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_stock_status' AND meta_value = %s AND post_id IN ( {$placeholders} ) LIMIT 1";
			} else {
				$query = "SELECT product_id FROM {$wpdb->wc_product_meta_lookup} WHERE stock_status = %s AND product_id IN ( {$placeholders} ) LIMIT 1";
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$has_matches = (bool) $wpdb->get_var( $wpdb->prepare( $query, $status, ...$child_ids ) );
		}

		return $has_matches;
	}

	/**
	 * Syncs all variation names if the parent name is changed.
	 *
	 * @param WC_Product $product Product object.
	 * @param string     $previous_name Variation previous name.
	 * @param string     $new_name Variation new name.
	 *
	 * @since 3.0.0
	 */
	public function sync_variation_names( &$product, $previous_name = '', $new_name = '' ) {
		if ( $new_name !== $previous_name ) {
			global $wpdb;

			$product_id = $product->get_id();
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->posts}
					SET post_title = REPLACE( post_title, %s, %s )
					WHERE post_type = 'product_variation'
					AND post_parent = %d",
					$previous_name ? $previous_name : 'AUTO-DRAFT',
					$new_name,
					$product_id
				)
			);

			$invalidator = wc_get_container()->get( ProductVersionStringInvalidator::class );
			foreach ( $product->get_children() as $child_id ) {
				clean_post_cache( $child_id );
				$invalidator->invalidate( $child_id );
			}
			$invalidator->invalidate( $product_id );
		}
	}

	/**
	 * Stock managed at the parent level - update children being managed by this product.
	 * This sync function syncs downwards (from parent to child) when the variable product is saved.
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since 3.0.0
	 */
	public function sync_managed_variation_stock_status( &$product ) {
		global $wpdb;

		if ( $product->get_manage_stock() ) {
			$child_ids = $product->get_children();
			if ( ! empty( $child_ids ) ) {
				$status       = $product->get_stock_status();
				$placeholders = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
				$children_to_sync     = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT post_id
						FROM {$wpdb->postmeta}
						WHERE meta_key = '_stock_status'
							AND meta_value != %s
							AND post_id IN ( SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_manage_stock' AND meta_value != 'yes' AND post_id IN ( {$placeholders} ) )",
						$status,
						...$child_ids
					)
				);
				$children_to_backfill = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT post_id
						FROM {$wpdb->postmeta}
						WHERE meta_key = '_manage_stock'
							AND meta_value != 'yes'
							AND post_id IN ( {$placeholders} )
							AND post_id NOT IN ( SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_stock_status' AND meta_value IS NOT NULL AND post_id IN ( {$placeholders} ) )",
						...$child_ids,
						...$child_ids
					)
				);
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

				$children_to_sync = array_unique( array_merge( $children_to_sync, $children_to_backfill ) );
				if ( ! empty( $children_to_sync ) ) {
					$invalidator = wc_get_container()->get( ProductVersionStringInvalidator::class );

					foreach ( $children_to_sync as $child_id ) {
						update_post_meta( $child_id, '_stock_status', $status );
						$this->update_lookup_table( $child_id, 'wc_product_meta_lookup' );
						$invalidator->invalidate( $child_id );
					}

					$children = $this->read_children( $product, true );
					$product->set_children( $children['all'] );
					$product->set_visible_children( $children['visible'] );
					$invalidator->invalidate( $product->get_id() );
				}
			}
		}
	}

	/**
	 * Sync variable product prices with children.
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @since 3.0.0
	 */
	public function sync_price( &$product ) {
		global $wpdb;

		$prices    = array();
		$child_ids = $product->get_visible_children();
		if ( ! empty( $child_ids ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $child_ids ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$prices = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_price' AND post_id IN ( {$placeholders} )",
					$child_ids
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		}

		$product_id = $product->get_id();

		// Performance note: prefilter with metadata_exists, to avoid unnecessary meta cache invalidations and SQLs.
		$price_metas = array_filter(
			array( '_price', '_sale_price', '_regular_price' ),
			static fn( $meta_key ) => metadata_exists( 'post', $product_id, $meta_key )
		);
		array_walk( $price_metas, static fn( $meta_key ) => delete_post_meta( $product_id, $meta_key ) );

		if ( $prices ) {
			sort( $prices, SORT_NUMERIC );
			// To allow sorting and filtering by multiple values, we have no choice but to store child prices in this manner.
			foreach ( $prices as $price ) {
				if ( is_null( $price ) || '' === $price ) {
					continue;
				}
				add_post_meta( $product_id, '_price', $price, false );
			}
		}

		$this->update_lookup_table( $product_id, 'wc_product_meta_lookup' );

		/**
		 * Fire an action for this direct update so it can be detected by other code.
		 *
		 * @since 3.6
		 * @param int $product_id Product ID that was updated directly.
		 */
		do_action( 'woocommerce_updated_product_price', $product_id );
	}

	/**
	 * Sync variable product stock status with children.
	 * Change does not persist unless saved by caller.
	 *
	 * @param WC_Product_Variable $product Product object.
	 *
	 * @since 3.0.0
	 */
	public function sync_stock_status( &$product ) {
		// Performance note: direct DB fetch would be faster, but child_is_in_stock/child_is_on_backorder are overridable — keep delegation.
		if ( $product->child_is_in_stock() ) {
			$product->set_stock_status( ProductStockStatus::IN_STOCK );
		} elseif ( $product->child_is_on_backorder() ) {
			$product->set_stock_status( ProductStockStatus::ON_BACKORDER );
		} else {
			$product->set_stock_status( ProductStockStatus::OUT_OF_STOCK );
		}
	}

	/**
	 * Delete variations of a product.
	 *
	 * @param int  $product_id Product ID.
	 * @param bool $force_delete False to trash.
	 *
	 * @since 3.0.0
	 */
	public function delete_variations( $product_id, $force_delete = false ) {
		if ( ! is_numeric( $product_id ) || 0 >= $product_id ) {
			return;
		}

		$variation_ids = wp_parse_id_list(
			get_posts(
				array(
					'post_parent' => $product_id,
					'post_type'   => 'product_variation',
					'fields'      => 'ids',
					'post_status' => array( 'any', ProductStatus::TRASH, ProductStatus::AUTO_DRAFT ),
					'numberposts' => -1, // phpcs:ignore WordPress.VIP.PostsPerPage.posts_per_page_numberposts
				)
			)
		);

		if ( ! empty( $variation_ids ) ) {
			foreach ( $variation_ids as $variation_id ) {
				if ( $force_delete ) {
					/**
					 * Fires before a product variation is permanently deleted.
					 *
					 * @since 3.0.0
					 *
					 * @param int $variation_id The variation ID being deleted.
					 */
					do_action( 'woocommerce_before_delete_product_variation', $variation_id );
					wp_delete_post( $variation_id, true );

					/**
					 * Fires after a product variation has been permanently deleted.
					 *
					 * @since 3.0.0
					 *
					 * @param int $variation_id The variation ID that was deleted.
					 */
					do_action( 'woocommerce_delete_product_variation', $variation_id );
				} else {
					wp_trash_post( $variation_id );

					/**
					 * Fires after a product variation has been trashed.
					 *
					 * @since 3.0.0
					 *
					 * @param int $variation_id The variation ID that was trashed.
					 */
					do_action( 'woocommerce_trash_product_variation', $variation_id );
				}
			}
		}

		wc_get_container()->get( ProductUtil::class )->delete_product_specific_transients_for_products( array( $product_id ) );
	}

	/**
	 * Untrash variations.
	 *
	 * @param int $product_id Product ID.
	 */
	public function untrash_variations( $product_id ) {
		$variation_ids = wp_parse_id_list(
			get_posts(
				array(
					'post_parent' => $product_id,
					'post_type'   => 'product_variation',
					'fields'      => 'ids',
					'post_status' => 'trash',
					'numberposts' => -1, // phpcs:ignore WordPress.VIP.PostsPerPage.posts_per_page_numberposts
				)
			)
		);

		if ( ! empty( $variation_ids ) ) {
			foreach ( $variation_ids as $variation_id ) {
				wp_untrash_post( $variation_id );
			}
		}

		wc_get_container()->get( ProductUtil::class )->delete_product_specific_transients_for_products( array( $product_id ) );
	}

	/**
	 * Validate the children data by checking the structure and type of the data.
	 *
	 * @param array  $children The children data.
	 * @param string $deprecated Was the current transient version, unused since 10.3.0.
	 * @return bool True if valid, false otherwise.
	 */
	protected function validate_children_data( $children, $deprecated ) {
		if ( ! is_array( $children ) ) {
			return false;
		}

		// Basic structure checks.
		if ( empty( $children['all'] ) || ! isset( $children['visible'] ) ) {
			return false;
		}

		if ( ! is_array( $children['all'] ) || ! is_array( $children['visible'] ) ) {
			return false;
		}

		foreach ( $children['all'] as $id ) {
			if ( ! is_numeric( $id ) ) {
				return false;
			}
		}

		foreach ( $children['visible'] as $id ) {
			if ( ! is_numeric( $id ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Validate the prices data by checking the structure and type of the data.
	 *
	 * @param  array  $prices_array The prices data.
	 * @param  string $deprecated Was the current transient version, unused since 10.3.0.
	 * @return bool True if valid, false otherwise.
	 */
	protected function validate_prices_data( $prices_array, $deprecated ) {
		if ( ! is_array( $prices_array ) ) {
			return false;
		}

		// Fail if array is empty - we want to rebuild in this case.
		if ( empty( $prices_array ) ) {
			return false;
		}

		$price_data_is_empty = true;

		foreach ( $prices_array as $price_data ) {
			if ( ! is_array( $price_data ) ) {
				return false;
			}

			$required_types = array( 'price', 'regular_price', 'sale_price' );

			foreach ( $required_types as $type ) {
				// If all 'price' fields are empty, we want to track that so we can rebuild the data.
				if ( 'price' === $type && ! empty( $price_data[ $type ] ) && $price_data_is_empty ) {
					$price_data_is_empty = false;
				}

				if ( ! isset( $price_data[ $type ] ) || ! is_array( $price_data[ $type ] ) ) {
					return false;
				}
			}

			$variation_ids = array_keys( $price_data['price'] );

			foreach ( $variation_ids as $variation_id ) {
				if ( ! is_numeric( $variation_id ) ) {
					return false;
				}

				foreach ( $required_types as $type ) {
					if ( ! array_key_exists( $variation_id, $price_data[ $type ] ) ) {
						return false;
					}

					$type_price = $price_data[ $type ][ $variation_id ];
					if ( ! is_numeric( $type_price ) && '' !== $type_price ) {
						return false;
					}
				}
			}
		}

		// If price is empty, we want to rebuild the data.
		if ( $price_data_is_empty ) {
			return false;
		}

		return true;
	}
}
