<?php
/**
 * Load assets
 *
 * @package WooCommerce\Admin
 * @version 3.7.0
 */

use Automattic\Jetpack\Constants;
use Automattic\WooCommerce\Admin\Features\Features;
use Automattic\WooCommerce\Enums\OrderStatus;
use Automattic\WooCommerce\Enums\ProductType;
use Automattic\WooCommerce\Internal\Admin\Analytics;
use Automattic\WooCommerce\Internal\Admin\WCAdminAssets;
use Automattic\WooCommerce\Internal\CostOfGoodsSold\CostOfGoodsSoldController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_Admin_Assets', false ) ) :

	/**
	 * WC_Admin_Assets Class.
	 *
	 * These scripts are enqueued in the admin of the store.  The registered script handles in this class
	 * can be used to enqueue the scripts in the admin by third party plugins and the handles will follow
	 * WooCommerce's L-1 support policy.  Scripts registered outside of this class do not guarantee support
	 * and can be removed in future versions of WooCommerce.
	 */
	class WC_Admin_Assets {

		/**
		 * Hook in tabs.
		 */
		public function __construct() {
			add_action( 'admin_init', array( $this, 'register_scripts' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_command_palette_assets' ) );
			add_action( 'admin_notices', array( $this, 'render_lost_connection_notice' ) );
		}

		/**
		 * Whether the current screen should get the #wc-lost-connection-notice markup and toggle handler.
		 * Limited to Woo admin screens, minus wc-admin React pages and classic post edit screens, which get WP
		 * core's own notice. Classic order edit is the exception: core's notice there wrongly claims local
		 * autosave backups are running, which disable_autosave() has turned off.
		 *
		 * @return bool Whether to render and toggle the notice.
		 */
		private function should_show_lost_connection_notice() {
			$screen = get_current_screen();

			if ( ! $screen || ! in_array( $screen->id, wc_get_screen_ids(), true ) ) {
				return false;
			}

			$is_wc_admin_page = class_exists( '\Automattic\WooCommerce\Admin\PageController' )
				&& \Automattic\WooCommerce\Admin\PageController::is_admin_page();
			if ( $is_wc_admin_page ) {
				return false;
			}

			$is_classic_order_edit_screen = 'post' === $screen->base
				&& in_array( $screen->post_type, wc_get_order_types( 'order-meta-boxes' ), true );

			return 'post' !== $screen->base || $is_classic_order_edit_screen;
		}

		/**
		 * Render a #wc-lost-connection-notice mirroring WP core's own notice on post edit screens.
		 * See should_show_lost_connection_notice() for which screens get it.
		 *
		 * @return void
		 */
		public function render_lost_connection_notice() {
			if ( ! $this->should_show_lost_connection_notice() ) {
				return;
			}
			?>
			<div id="wc-lost-connection-notice" class="notice error hidden">
				<p>
					<span class="spinner"></span>
					<strong><?php esc_html_e( 'Connection lost.' ); /* phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- Reusing WP core translation. */ ?></strong>
					<?php esc_html_e( 'Saving has been disabled until you are reconnected.' ); /* phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- Reusing WP core translation. */ ?>
				</p>
			</div>
			<?php
		}

		/**
		 * Enqueue styles.
		 */
		public function admin_styles() {
			$version   = Constants::get_constant( 'WC_VERSION' );
			$screen    = get_current_screen();
			$screen_id = $screen ? $screen->id : '';

			// Register admin styles.
			wp_register_style( 'woocommerce_admin_menu_styles', WC()->plugin_url() . '/assets/css/menu.css', array(), $version );
			wp_register_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), $version );
			wp_register_style( 'jquery-ui-style', WC()->plugin_url() . '/assets/css/jquery-ui/jquery-ui.min.css', array(), $version );
			wp_register_style( 'woocommerce_admin_dashboard_styles', WC()->plugin_url() . '/assets/css/dashboard.css', array(), $version );
			wp_register_style( 'woocommerce_admin_print_reports_styles', WC()->plugin_url() . '/assets/css/reports-print.css', array(), $version, 'print' );
			wp_register_style( 'woocommerce_admin_marketplace_styles', WC()->plugin_url() . '/assets/css/marketplace-suggestions.css', array(), $version );
			wp_register_style( 'woocommerce_admin_privacy_styles', WC()->plugin_url() . '/assets/css/privacy.css', array(), $version );

			// Add RTL support for admin styles.
			wp_style_add_data( 'woocommerce_admin_menu_styles', 'rtl', 'replace' );
			wp_style_add_data( 'woocommerce_admin_styles', 'rtl', 'replace' );
			wp_style_add_data( 'woocommerce_admin_dashboard_styles', 'rtl', 'replace' );
			wp_style_add_data( 'woocommerce_admin_print_reports_styles', 'rtl', 'replace' );
			wp_style_add_data( 'woocommerce_admin_marketplace_styles', 'rtl', 'replace' );
			wp_style_add_data( 'woocommerce_admin_privacy_styles', 'rtl', 'replace' );

			if ( $screen && $screen->is_block_editor() ) {
				if ( ! wp_is_block_theme() ) {
					wp_register_style( 'woocommerce-classictheme-editor-fonts', WC()->plugin_url() . '/assets/css/woocommerce-classictheme-editor-fonts.css', array(), $version );
					wp_enqueue_style( 'woocommerce-classictheme-editor-fonts' );
				}

				$styles = WC_Frontend_Scripts::get_styles();

				if ( $styles ) {
					foreach ( $styles as $handle => $args ) {
						wp_register_style(
							$handle,
							$args['src'],
							$args['deps'],
							$args['version'],
							$args['media']
						);

						if ( ! isset( $args['has_rtl'] ) ) {
							wp_style_add_data( $handle, 'rtl', 'replace' );
						}

						wp_enqueue_style( $handle );
					}
				}
			}

			// Sitewide menu CSS.
			wp_enqueue_style( 'woocommerce_admin_menu_styles' );

			// Admin styles for WC pages only.
			if ( in_array( $screen_id, wc_get_screen_ids() ) ) {
				wp_enqueue_style( 'woocommerce_admin_styles' );
				wp_enqueue_style( 'jquery-ui-style' );
				wp_enqueue_style( 'wp-color-picker' );
			}

			if ( in_array( $screen_id, array( 'dashboard' ) ) ) {
				wp_enqueue_style( 'woocommerce_admin_dashboard_styles' );
			}

			if ( in_array( $screen_id, array( 'woocommerce_page_wc-reports', 'toplevel_page_wc-reports' ) ) ) {
				wp_enqueue_style( 'woocommerce_admin_print_reports_styles' );
			}

			// Privacy Policy Guide css for back-compat.
			if ( isset( $_GET['wp-privacy-policy-guide'] ) || in_array( $screen_id, array( 'privacy-policy-guide' ) ) ) {
				wp_enqueue_style( 'woocommerce_admin_privacy_styles' );
			}

			// @deprecated 2.3.
			if ( has_action( 'woocommerce_admin_css' ) ) {
				/* phpcs:disable WooCommerce.Commenting.CommentHooks.MissingHookComment */
				do_action( 'woocommerce_admin_css' );
				/* phpcs: enable */
				wc_deprecated_function( 'The woocommerce_admin_css action', '2.3', 'admin_enqueue_scripts' );
			}

			if ( WC_Marketplace_Suggestions::show_suggestions_for_screen( $screen_id ) ) {
				wp_enqueue_style( 'woocommerce_admin_marketplace_styles' );
			}
		}

		/**
		 * Get the scripts used for registration.
		 *
		 * @return array
		 */
		private function get_scripts(): array {
			$suffix     = Constants::is_true( 'SCRIPT_DEBUG' ) ? '' : '.min';
			$version    = Constants::get_constant( 'WC_VERSION' );
			$plugin_url = WC()->plugin_url();

			return array(
				array(
					'handle'       => 'woocommerce_admin',
					'path'         => $plugin_url . '/assets/js/admin/woocommerce_admin' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wc-jquery-blockui', 'jquery-ui-sortable', 'jquery-ui-widget', 'jquery-ui-core', 'wc-jquery-tiptip' ),
					'version'      => $version,
				),
				array(
					'legacy_handle' => 'jquery-blockui',
					'handle'        => 'wc-jquery-blockui',
					'path'          => $plugin_url . '/assets/js/jquery-blockui/jquery.blockUI' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => '2.70',
					'args'          => array(
						'in_footer' => true,
					),
				),
				array(
					'legacy_handle' => 'jquery-tiptip',
					'handle'        => 'wc-jquery-tiptip',
					'path'          => $plugin_url . '/assets/js/jquery-tiptip/jquery.tipTip' . $suffix . '.js',
					'dependencies'  => array( 'jquery', 'wc-dompurify' ),
					'version'       => $version,
					'args'          => array(
						'in_footer' => true,
					),
				),
				array(
					'legacy_handle' => 'round',
					'handle'        => 'wc-round',
					'path'          => $plugin_url . '/assets/js/round/round' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => $version,
				),
				array(
					'handle'       => 'wc-admin-meta-boxes',
					'path'         => $plugin_url . '/assets/js/admin/meta-boxes' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable', 'wc-accounting', 'wc-round', 'wc-enhanced-select', 'plupload-all', 'wc-stupidtable', 'wc-jquery-tiptip', 'wc-jquery-blockui' ),
					'version'      => $version,
				),
				array(
					'legacy_handle' => 'qrcode',
					'handle'        => 'wc-qrcode',
					'path'          => $plugin_url . '/assets/js/jquery-qrcode/jquery.qrcode' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'stupidtable',
					'handle'        => 'wc-stupidtable',
					'path'          => $plugin_url . '/assets/js/stupidtable/stupidtable' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'serializejson',
					'handle'        => 'wc-serializejson',
					'path'          => $plugin_url . '/assets/js/jquery-serializejson/jquery.serializejson' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => '2.8.1',
				),
				array(
					'legacy_handle' => 'flot',
					'handle'        => 'wc-flot',
					'path'          => $plugin_url . '/assets/js/jquery-flot/jquery.flot' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'flot-resize',
					'handle'        => 'wc-flot-resize',
					'path'          => $plugin_url . '/assets/js/jquery-flot/jquery.flot.resize' . $suffix . '.js',
					'dependencies'  => array( 'jquery', 'wc-flot' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'flot-time',
					'handle'        => 'wc-flot-time',
					'path'          => $plugin_url . '/assets/js/jquery-flot/jquery.flot.time' . $suffix . '.js',
					'dependencies'  => array( 'jquery', 'wc-flot' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'flot-pie',
					'handle'        => 'wc-flot-pie',
					'path'          => $plugin_url . '/assets/js/jquery-flot/jquery.flot.pie' . $suffix . '.js',
					'dependencies'  => array( 'jquery', 'wc-flot' ),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'flot-stack',
					'handle'        => 'wc-flot-stack',
					'path'          => $plugin_url . '/assets/js/jquery-flot/jquery.flot.stack' . $suffix . '.js',
					'dependencies'  => array( 'jquery', 'wc-flot' ),
					'version'       => $version,
				),
				array(
					'handle'       => 'wc-settings-tax',
					'path'         => $plugin_url . '/assets/js/admin/settings-views-html-settings-tax' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wp-util', 'underscore', 'backbone', 'wc-jquery-blockui' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-backbone-modal',
					'path'         => $plugin_url . '/assets/js/admin/backbone-modal' . $suffix . '.js',
					'dependencies' => array( 'underscore', 'backbone', 'wp-util' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-shipping-zones',
					'path'         => $plugin_url . '/assets/js/admin/wc-shipping-zones' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wp-util', 'underscore', 'backbone', 'jquery-ui-sortable', 'wc-enhanced-select', 'wc-backbone-modal' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-shipping-zone-methods',
					'path'         => $plugin_url . '/assets/js/admin/wc-shipping-zone-methods' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wp-util', 'underscore', 'backbone', 'jquery-ui-sortable', 'wc-backbone-modal' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-shipping-classes',
					'path'         => $plugin_url . '/assets/js/admin/wc-shipping-classes' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wp-util', 'underscore', 'backbone', 'wc-backbone-modal' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-shipping-providers',
					'path'         => $plugin_url . '/assets/js/admin/wc-shipping-providers' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'wp-util', 'underscore', 'backbone', 'wc-backbone-modal' ),
					'version'      => $version,
				),
				array(
					'handle'       => 'wc-clipboard',
					'path'         => $plugin_url . '/assets/js/admin/wc-clipboard' . $suffix . '.js',
					'dependencies' => array( 'jquery' ),
					'version'      => $version,
				),
				array(
					'legacy_handle' => 'select2',
					'handle'        => 'wc-select2',
					'path'          => $plugin_url . '/assets/js/select2/select2.full' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => '4.0.3',
				),
				array(
					'handle'       => 'selectWoo',
					'path'         => $plugin_url . '/assets/js/selectWoo/selectWoo.full' . $suffix . '.js',
					'dependencies' => array( 'jquery' ),
					'version'      => '1.0.6',
				),
				array(
					'handle'       => 'wc-enhanced-select',
					'path'         => $plugin_url . '/assets/js/admin/wc-enhanced-select' . $suffix . '.js',
					'dependencies' => array( 'jquery', 'selectWoo' ),
					'version'      => $version,
				),
				array(
					'legacy_handle' => 'js-cookie',
					'handle'        => 'wc-js-cookie',
					'path'          => $plugin_url . '/assets/js/js-cookie/js.cookie' . $suffix . '.js',
					'dependencies'  => array(),
					'version'       => '2.1.4',
					'args'          => array(
						'in_footer' => true,
					),
				),
				array(
					'legacy_handle' => 'dompurify',
					'handle'        => 'wc-dompurify',
					'path'          => $plugin_url . '/assets/js/dompurify/purify' . $suffix . '.js',
					'dependencies'  => array(),
					'version'       => $version,
				),
				array(
					'legacy_handle' => 'accounting',
					'handle'        => 'wc-accounting',
					'path'          => $plugin_url . '/assets/js/accounting/accounting' . $suffix . '.js',
					'dependencies'  => array( 'jquery' ),
					'version'       => '0.4.2',
				),
			);
		}

		/**
		 * Register the scripts.
		 *
		 * These scripts are registered early to allow other
		 * plugins to take advantage of them by handle.
		 */
		public function register_scripts() {
			$scripts = $this->get_scripts();

			foreach ( $scripts as $script ) {
				wp_register_script(
					$script['handle'],
					$script['path'],
					$script['dependencies'] ?? array(),
					$script['version'] ?? null,
					$script['args'] ?? array( 'in_footer' => false )
				);

				if ( isset( $script['legacy_handle'] ) ) {
					wp_register_script(
						$script['legacy_handle'],
						false,
						array( $script['handle'] ),
						$script['version'] ?? null,
						true
					);
				}
			}

			wp_localize_script(
				'wc-enhanced-select',
				'wc_enhanced_select_params',
				array(
					'i18n_no_matches'                 => _x( 'No matches found', 'enhanced select', 'woocommerce' ),
					'i18n_ajax_error'                 => _x( 'Loading failed', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_short_1'          => _x( 'Please enter 1 or more characters', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_short_n'          => _x( 'Please enter %qty% or more characters', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_long_1'           => _x( 'Please delete 1 character', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_long_n'           => _x( 'Please delete %qty% characters', 'enhanced select', 'woocommerce' ),
					'i18n_selection_too_long_1'       => _x( 'You can only select 1 item', 'enhanced select', 'woocommerce' ),
					'i18n_selection_too_long_n'       => _x( 'You can only select %qty% items', 'enhanced select', 'woocommerce' ),
					'i18n_load_more'                  => _x( 'Loading more results&hellip;', 'enhanced select', 'woocommerce' ),
					'i18n_searching'                  => _x( 'Searching&hellip;', 'enhanced select', 'woocommerce' ),
					'i18n_loading_tax_rates'          => _x( 'Loading tax rates…', 'order tax rate search status', 'woocommerce' ),
					/* translators: %s: tax rate search term. */
					'i18n_tax_rate_search_results'    => _x( 'Showing results for “%s”', 'order tax rate search results summary', 'woocommerce' ),
					'i18n_clear_tax_rate_search'      => _x( 'Clear search', 'order tax rate search results action', 'woocommerce' ),
					'i18n_no_tax_rates'               => _x( 'No tax rates have been set up yet.', 'order tax rate empty state', 'woocommerce' ),
					'i18n_no_tax_rates_help'          => _x( 'Set up tax rates or enable automated tax calculation before adding tax to this order.', 'order tax rate empty state', 'woocommerce' ),
					'i18n_tax_settings'               => _x( 'Go to tax settings', 'order tax rate empty state action', 'woocommerce' ),
					/* translators: 1: tax class, 2: rate code, 3: rate percentage. */
					'i18n_tax_rate_details'           => _x( 'Tax class: %1$s. Rate code: %2$s. Rate: %3$s.', 'tax rate option screen reader details', 'woocommerce' ),
					'tax_rates_settings_url'          => admin_url( 'admin.php?page=wc-settings&tab=tax' ),
					'ajax_url'                        => admin_url( 'admin-ajax.php' ),
					'search_products_nonce'           => wp_create_nonce( 'search-products' ),
					'search_tax_rates_nonce'          => wp_create_nonce( 'search-tax-rates' ),
					'search_customers_nonce'          => wp_create_nonce( 'search-customers' ),
					'search_categories_nonce'         => wp_create_nonce( 'search-categories' ),
					'search_taxonomy_terms_nonce'     => wp_create_nonce( 'search-taxonomy-terms' ),
					'search_product_attributes_nonce' => wp_create_nonce( 'search-product-attributes' ),
					'search_pages_nonce'              => wp_create_nonce( 'search-pages' ),
					'search_order_metakeys_nonce'     => wp_create_nonce( 'search-order-metakeys' ),
				)
			);

			wp_localize_script(
				'wc-accounting',
				'accounting_params',
				array(
					'mon_decimal_point' => wc_get_price_decimal_separator(),
				)
			);
		}


		/**
		 * Enqueue scripts.
		 */
		public function admin_scripts() {
			global $wp_query, $post, $theorder;

			$screen       = get_current_screen();
			$screen_id    = $screen ? $screen->id : '';
			$wc_screen_id = 'woocommerce';
			$suffix       = Constants::is_true( 'SCRIPT_DEBUG' ) ? '' : '.min';
			$version      = Constants::get_constant( 'WC_VERSION' );

			wp_register_script( 'wc-orders', WC()->plugin_url() . '/assets/js/admin/wc-orders' . $suffix . '.js', array( 'jquery', 'wp-util', 'underscore', 'backbone', 'wc-jquery-blockui' ), $version, array( 'in_footer' => false ) );
			wp_localize_script(
				'wc-orders',
				'wc_orders_params',
				array(
					'ajax_url'      => admin_url( 'admin-ajax.php' ),
					'preview_nonce' => wp_create_nonce( 'woocommerce-preview-order' ),
				)
			);

			// WooCommerce admin pages.
			if ( in_array( $screen_id, wc_get_screen_ids() ) ) {
				wp_enqueue_script( 'iris' );
				wp_enqueue_script( 'woocommerce_admin' );
				wp_enqueue_script( 'wc-enhanced-select' );

				$show_lost_connection_notice = $this->should_show_lost_connection_notice();

				// The notice is toggled via heartbeat events (see woocommerce_admin.js), so ensure the emitter is loaded.
				if ( $show_lost_connection_notice ) {
					wp_enqueue_script( 'heartbeat' );
				}

				wp_enqueue_script( 'jquery-ui-sortable' );
				wp_enqueue_script( 'jquery-ui-autocomplete' );

				$locale        = localeconv();
				$decimal_point = isset( $locale['decimal_point'] ) ? $locale['decimal_point'] : '.';
				$decimal       = ( ! empty( wc_get_price_decimal_separator() ) ) ? wc_get_price_decimal_separator() : $decimal_point;

				$params = array(
					/* translators: %s: decimal */
					'i18n_decimal_error'                => sprintf( __( 'Please enter a value with one decimal point (%s) without thousand separators.', 'woocommerce' ), $decimal ),
					/* translators: %s: price decimal separator */
					'i18n_mon_decimal_error'            => sprintf( __( 'Please enter a value with one monetary decimal point (%s) without thousand separators and currency symbols.', 'woocommerce' ), wc_get_price_decimal_separator() ),
					'i18n_country_iso_error'            => __( 'Please enter in country code with two capital letters.', 'woocommerce' ),
					'i18n_sale_less_than_regular_error' => __( 'Please enter in a value less than the regular price.', 'woocommerce' ),
					'i18n_delete_product_notice'        => __( 'This product has produced sales and may be linked to existing orders. Are you sure you want to delete it?', 'woocommerce' ),
					'i18n_remove_personal_data_notice'  => __( 'This action cannot be reversed. Are you sure you wish to erase personal data from the selected orders?', 'woocommerce' ),
					'i18n_confirm_delete'               => __( 'Are you sure you wish to delete this item?', 'woocommerce' ),
					'i18n_global_unique_id_error'       => __( 'Enter only numbers and hyphens (-). The letter X is allowed only as the final ISBN-10 check digit.', 'woocommerce' ),
					'decimal_point'                     => $decimal,
					'mon_decimal_point'                 => wc_get_price_decimal_separator(),
					'ajax_url'                          => admin_url( 'admin-ajax.php' ),
					'strings'                           => array(
						'import_products'          => __( 'Import', 'woocommerce' ),
						'export_products'          => __( 'Export', 'woocommerce' ),
						// translators: %d: number of selected products.
						'export_selected_products' => __( 'Export %d selected', 'woocommerce' ),
					),
					'nonces'                            => array(
						'gateway_toggle'                 => current_user_can( 'manage_woocommerce' ) ? wp_create_nonce( 'woocommerce-toggle-payment-gateway-enabled' ) : null,
						'export_selected_products_nonce' => current_user_can( 'export' ) ? wp_create_nonce( 'export-selected-products' ) : null,
					),
					'urls'                              => array(
						'add_product'     => null,
						'import_products' => current_user_can( 'import' ) ? esc_url_raw( admin_url( 'edit.php?post_type=product&page=product_importer' ) ) : null,
						'export_products' => current_user_can( 'export' ) ? esc_url_raw( admin_url( 'edit.php?post_type=product&page=product_exporter' ) ) : null,
					),
					'show_lost_connection_notice'       => $show_lost_connection_notice,
				);

				wp_localize_script( 'woocommerce_admin', 'woocommerce_admin', $params );
			}

			// Edit product category pages.
			if ( in_array( $screen_id, array( 'edit-product_cat' ) ) ) {
				wp_enqueue_media();
			}

			// Products.
			if ( in_array( $screen_id, array( 'edit-product' ) ) ) {
				wp_enqueue_script( 'jquery-ui-datepicker' );
				wp_enqueue_script( 'woocommerce_quick-edit', WC()->plugin_url() . '/assets/js/admin/quick-edit' . $suffix . '.js', array( 'jquery', 'woocommerce_admin' ), $version, false );

				$params = array(
					'strings' => array(
						'allow_reviews' => esc_js( __( 'Enable reviews', 'woocommerce' ) ),
					),
				);

				wp_localize_script( 'woocommerce_quick-edit', 'woocommerce_quick_edit', $params );
			}

			// Product description.
			if ( in_array( $screen_id, array( 'product' ), true ) ) {
				wp_enqueue_script( 'wc-admin-product-editor', WC()->plugin_url() . '/assets/js/admin/product-editor' . $suffix . '.js', array( 'jquery' ), $version, false );

				wp_localize_script(
					'wc-admin-product-editor',
					'woocommerce_admin_product_editor',
					array(
						'i18n_description' => esc_js( __( 'Product description', 'woocommerce' ) ),
					)
				);
			}

			// Meta boxes.
			/* phpcs:disable */
			if ( in_array( $screen_id, array( 'product', 'edit-product' ) ) ) {
				wp_enqueue_media();
				wp_register_script( 'wc-admin-product-meta-boxes', WC()->plugin_url() . '/assets/js/admin/meta-boxes-product' . $suffix . '.js', array( 'wc-admin-meta-boxes', 'media-models', 'underscore' ), $version );
				wp_register_script( 'wc-admin-variation-meta-boxes', WC()->plugin_url() . '/assets/js/admin/meta-boxes-product-variation' . $suffix . '.js', array( 'wc-admin-meta-boxes', 'wc-serializejson', 'media-models', 'backbone', 'jquery-ui-sortable', 'wc-backbone-modal', 'wp-data', 'wp-notices' ), $version );

				wp_enqueue_script( 'wc-admin-product-meta-boxes' );
				wp_enqueue_script( 'wc-admin-variation-meta-boxes' );

				$params = array(
					'post_id'                             => isset( $post->ID ) ? $post->ID : '',
					'plugin_url'                          => WC()->plugin_url(),
					'ajax_url'                            => admin_url( 'admin-ajax.php' ),
					'woocommerce_placeholder_img_src'     => wc_placeholder_img_src(),
					'add_variation_nonce'                 => wp_create_nonce( 'add-variation' ),
					'link_variation_nonce'                => wp_create_nonce( 'link-variations' ),
					'delete_variations_nonce'             => wp_create_nonce( 'delete-variations' ),
					'load_variations_nonce'               => wp_create_nonce( 'load-variations' ),
					'save_variations_nonce'               => wp_create_nonce( 'save-variations' ),
					'bulk_edit_variations_nonce'          => wp_create_nonce( 'bulk-edit-variations' ),
					/* translators: %d: Number of variations */
					'i18n_link_all_variations'            => esc_js( sprintf( __( 'Do you want to generate all variations? This will create a new variation for each and every possible combination of variation attributes (max %d per run).', 'woocommerce' ), Constants::is_defined( 'WC_MAX_LINKED_VARIATIONS' ) ? Constants::get_constant( 'WC_MAX_LINKED_VARIATIONS' ) : 50 ) ),
					'i18n_enter_a_value'                  => esc_js( __( 'Enter a value', 'woocommerce' ) ),
					'i18n_enter_menu_order'               => esc_js( __( 'Variation menu order (determines position in the list of variations)', 'woocommerce' ) ),
					'i18n_enter_a_value_fixed_or_percent' => esc_js( __( 'Enter a value (fixed or %)', 'woocommerce' ) ),
					'i18n_sale_price_warning'            => esc_js( __( 'Warning: Sale prices will be removed if they are not lower than regular prices.', 'woocommerce' ) ),
					'i18n_delete_all_variations'          => esc_js( __( 'Are you sure you want to delete all variations? This cannot be undone.', 'woocommerce' ) ),
					'i18n_last_warning'                   => esc_js( __( 'Last warning, are you sure?', 'woocommerce' ) ),
					'i18n_choose_image'                   => esc_js( __( 'Choose an image', 'woocommerce' ) ),
					'i18n_set_image'                      => esc_js( __( 'Set variation image', 'woocommerce' ) ),
					'i18n_variation_added'                => esc_js( __( '1 variation added', 'woocommerce' ) ),
					'i18n_variations_added'               => esc_js( __( '%qty% variations added', 'woocommerce' ) ),
					'i18n_remove_variation'               => esc_js( __( 'Are you sure you want to remove this variation?', 'woocommerce' ) ),
					'i18n_scheduled_sale_start'           => esc_js( __( 'Sale start date (YYYY-MM-DD format or leave blank)', 'woocommerce' ) ),
					'i18n_scheduled_sale_end'             => esc_js( __( 'Sale end date (YYYY-MM-DD format or leave blank)', 'woocommerce' ) ),
					'i18n_scheduled_sale_end_before_start' => esc_js( __( 'The sale end date cannot be earlier than the sale start date.', 'woocommerce' ) ),
					'i18n_edited_variations'              => esc_js( __( 'Save changes before changing page?', 'woocommerce' ) ),
					'i18n_generate_variations'            => esc_js( __( 'Generate variations', 'woocommerce' ) ),
					'i18n_variation_count_single'         => esc_js( __( '1 variation', 'woocommerce' ) ),
					'i18n_variation_count_plural'         => esc_js( __( '%qty% variations', 'woocommerce' ) ),
					'i18n_variation_cost_remove_warning'  => esc_js( __( 'The custom cost of goods sold values will revert back to their defaults for all the variations. Would you like to continue?', 'woocommerce' ) ),
					'variations_per_page'                 => absint( apply_filters( 'woocommerce_admin_meta_boxes_variations_per_page', 15 ) ),
				);

				wp_localize_script( 'wc-admin-variation-meta-boxes', 'woocommerce_admin_meta_boxes_variations', $params );
			}
			/* phpcs: enable */
			if ( $this->is_order_meta_box_screen( $screen_id ) ) {
				$default_location = wc_get_customer_default_location();

				wp_enqueue_script( 'wc-admin-order-meta-boxes', WC()->plugin_url() . '/assets/js/admin/meta-boxes-order' . $suffix . '.js', array( 'wc-admin-meta-boxes', 'wc-backbone-modal', 'selectWoo', 'wc-clipboard', 'wp-a11y' ), $version );
				wp_localize_script(
					'wc-admin-order-meta-boxes',
					'woocommerce_admin_meta_boxes_order',
					array(
						'countries'              => wp_json_encode(
							array_merge( WC()->countries->get_allowed_country_states(), WC()->countries->get_shipping_country_states() ),
							JSON_HEX_TAG | JSON_UNESCAPED_SLASHES
						),
						'i18n_select_state_text' => esc_attr__( 'Select an option&hellip;', 'woocommerce' ),
						'default_country'        => isset( $default_location['country'] ) ? $default_location['country'] : '',
						'default_state'          => isset( $default_location['state'] ) ? $default_location['state'] : '',
						'placeholder_name'       => esc_attr__( 'Name (required)', 'woocommerce' ),
						'placeholder_value'      => esc_attr__( 'Value (required)', 'woocommerce' ),
					)
				);
			}
			/* phpcs:disable WooCommerce.Commenting.CommentHooks.MissingHookComment */
			if ( in_array( $screen_id, array( 'shop_coupon', 'edit-shop_coupon' ) ) ) {
				wp_enqueue_script( 'wc-admin-coupon-meta-boxes', WC()->plugin_url() . '/assets/js/admin/meta-boxes-coupon' . $suffix . '.js', array( 'wc-admin-meta-boxes' ), $version );
				wp_localize_script(
					'wc-admin-coupon-meta-boxes',
					'woocommerce_admin_meta_boxes_coupon',
					array(
						'generate_button_text' => esc_html__( 'Generate coupon code', 'woocommerce' ),
						'characters'           => apply_filters( 'woocommerce_coupon_code_generator_characters', 'ABCDEFGHJKMNPQRSTUVWXYZ23456789' ),
						'char_length'          => apply_filters( 'woocommerce_coupon_code_generator_character_length', 8 ),
						'prefix'               => apply_filters( 'woocommerce_coupon_code_generator_prefix', '' ),
						'suffix'               => apply_filters( 'woocommerce_coupon_code_generator_suffix', '' ),
					)
				);
			}
			/* phpcs: enable */
			if ( in_array( str_replace( 'edit-', '', $screen_id ), array( 'shop_coupon', 'product' ), true ) || $this->is_order_meta_box_screen( $screen_id ) ) {
				$post_id                = isset( $post->ID ) ? $post->ID : '';
				$currency               = '';
				$remove_item_notice     = __( 'Are you sure you want to remove the selected items?', 'woocommerce' );
				$remove_fee_notice      = __( 'Are you sure you want to remove the selected fees?', 'woocommerce' );
				$remove_shipping_notice = __( 'Are you sure you want to remove the selected shipping?', 'woocommerce' );

				// Eventually this will become wc_data_or_post object as we implement more custom tables.
				$order_or_post_object = $post;
				if ( ( $theorder instanceof WC_Order ) && $this->is_order_meta_box_screen( $screen_id ) ) {
					$order_or_post_object = $theorder;
					if ( $order_or_post_object ) {
						$currency = $order_or_post_object->get_currency();

						if ( ! $order_or_post_object->has_status( array( OrderStatus::PENDING, OrderStatus::FAILED, OrderStatus::CANCELLED ) ) ) {
							$remove_item_notice = $remove_item_notice . ' ' . __( "You may need to manually restore the item's stock.", 'woocommerce' );
						}
					}
				}

				$params = array(
					'remove_item_notice'                              => $remove_item_notice,
					'remove_fee_notice'                               => $remove_fee_notice,
					'remove_shipping_notice'                          => $remove_shipping_notice,
					'i18n_select_items'                               => __( 'Please select some items.', 'woocommerce' ),
					'i18n_do_refund'                                  => __( 'Are you sure you wish to process this refund? This action cannot be undone.', 'woocommerce' ),
					'i18n_delete_refund'                              => __( 'Are you sure you wish to delete this refund? This action cannot be undone.', 'woocommerce' ),
					'i18n_delete_tax'                                 => __( 'Are you sure you wish to delete this tax column? This action cannot be undone.', 'woocommerce' ),
					'i18n_no_title'                                   => __( '(no title)', 'woocommerce' ),
					'remove_item_meta'                                => __( 'Remove this item meta?', 'woocommerce' ),
					'name_label'                                      => __( 'Name', 'woocommerce' ),
					'remove_label'                                    => __( 'Remove', 'woocommerce' ),
					'click_to_toggle'                                 => __( 'Click to toggle', 'woocommerce' ),
					'values_label'                                    => __( 'Value(s)', 'woocommerce' ),
					'text_attribute_tip'                              => __( 'Enter some text, or some attributes by pipe (|) separating values.', 'woocommerce' ),
					'visible_label'                                   => __( 'Visible on the product page', 'woocommerce' ),
					'used_for_variations_label'                       => __( 'Used for variations', 'woocommerce' ),
					'new_attribute_prompt'                            => __( 'Enter a name for the new attribute term:', 'woocommerce' ),
					'calc_totals'                                     => __( 'Recalculate totals? This will calculate taxes based on the customers country (or the store base country) and update totals.', 'woocommerce' ),
					'copy_billing'                                    => __( 'Copy billing information to shipping information? This will remove any currently entered shipping information.', 'woocommerce' ),
					'load_billing'                                    => __( "Load the customer's billing information? This will remove any currently entered billing information.", 'woocommerce' ),
					'load_shipping'                                   => __( "Load the customer's shipping information? This will remove any currently entered shipping information.", 'woocommerce' ),
					'featured_label'                                  => __( 'Featured', 'woocommerce' ),
					'prices_include_tax'                              => esc_attr( get_option( 'woocommerce_prices_include_tax' ) ),
					'tax_based_on'                                    => esc_attr( get_option( 'woocommerce_tax_based_on' ) ),
					'round_at_subtotal'                               => esc_attr( get_option( 'woocommerce_tax_round_at_subtotal' ) ),
					'no_customer_selected'                            => __( 'No customer selected', 'woocommerce' ),
					'plugin_url'                                      => WC()->plugin_url(),
					'ajax_url'                                        => admin_url( 'admin-ajax.php' ),
					'order_item_nonce'                                => wp_create_nonce( 'order-item' ),
					'add_attribute_nonce'                             => wp_create_nonce( 'add-attribute' ),
					'save_attributes_nonce'                           => wp_create_nonce( 'save-attributes' ),
					'add_attributes_and_variations'                   => wp_create_nonce( 'add-attributes-and-variations' ),
					'calc_totals_nonce'                               => wp_create_nonce( 'calc-totals' ),
					'get_customer_details_nonce'                      => wp_create_nonce( 'get-customer-details' ),
					'search_products_nonce'                           => wp_create_nonce( 'search-products' ),
					'grant_access_nonce'                              => wp_create_nonce( 'grant-access' ),
					'revoke_access_nonce'                             => wp_create_nonce( 'revoke-access' ),
					'add_order_note_nonce'                            => wp_create_nonce( 'add-order-note' ),
					'delete_order_note_nonce'                         => wp_create_nonce( 'delete-order-note' ),
					'calendar_image'                                  => WC()->plugin_url() . '/assets/images/calendar.png',
					'post_id'                                         => $this->is_order_meta_box_screen( $screen_id ) && isset( $order_or_post_object ) ? \Automattic\WooCommerce\Utilities\OrderUtil::get_post_or_order_id( $order_or_post_object ) : $post_id,
					'base_country'                                    => WC()->countries->get_base_country(),
					'currency_format_num_decimals'                    => wc_get_price_decimals(),
					'currency_format_symbol'                          => get_woocommerce_currency_symbol( $currency ),
					'currency_format_decimal_sep'                     => esc_attr( wc_get_price_decimal_separator() ),
					'currency_format_thousand_sep'                    => esc_attr( wc_get_price_thousand_separator() ),
					'currency_format'                                 => esc_attr( str_replace( array( '%1$s', '%2$s' ), array( '%s', '%v' ), get_woocommerce_price_format() ) ), // For accounting JS.
					'rounding_precision'                              => wc_get_rounding_precision(),
					'tax_rounding_mode'                               => wc_get_tax_rounding_mode(),
					'product_types'                                   => array_unique( array_merge( array( ProductType::SIMPLE, ProductType::GROUPED, ProductType::VARIABLE, ProductType::EXTERNAL ), array_keys( wc_get_product_types() ) ) ),
					'i18n_download_permission_fail'                   => __( 'Could not grant access - the user may already have permission for this file or billing email is not set. Ensure the billing email is set, and the order has been saved.', 'woocommerce' ),
					'i18n_permission_revoke'                          => __( 'Are you sure you want to revoke access to this download?', 'woocommerce' ),
					'i18n_tax_rate_already_exists'                    => __( 'You cannot add the same tax rate twice!', 'woocommerce' ),
					'i18n_delete_note'                                => __( 'Are you sure you wish to delete this note? This action cannot be undone.', 'woocommerce' ),
					'i18n_delete_customer_note'                       => __( 'Are you sure you wish to delete this note? This action cannot be undone. Caution: This only removes the note from your records — it does not recall the email already sent to the customer.', 'woocommerce' ),
					'i18n_no_notes_yet'                               => __( 'There are no notes yet.', 'woocommerce' ),
					'i18n_order_note_added'                           => __( 'Order note added.', 'woocommerce' ),
					'i18n_customer_order_note_added'                  => __( 'Order note added and emailed to the customer.', 'woocommerce' ),
					'i18n_apply_coupon'                               => __( 'Enter a coupon code to apply. Discounts are applied to line totals, before taxes.', 'woocommerce' ),
					'i18n_add_fee'                                    => __( 'Enter a fixed amount or percentage to apply as a fee.', 'woocommerce' ),
					'i18n_attribute_name_placeholder'                 => __( 'New attribute', 'woocommerce' ),
					'i18n_product_simple_tip'                         => __( '<b>Simple –</b> covers the vast majority of any products you may sell. Simple products are shipped and have no options. For example, a book.', 'woocommerce' ),
					'i18n_product_grouped_tip'                        => __( '<b>Grouped –</b> a collection of related products that can be purchased individually and only consist of simple products. For example, a set of six drinking glasses.', 'woocommerce' ),
					'i18n_product_external_tip'                       => __( '<b>External or Affiliate –</b> one that you list and describe on your website but is sold elsewhere.', 'woocommerce' ),
					'i18n_product_variable_tip'                       => __( '<b>Variable –</b> a product with variations, each of which may have a different SKU, price, stock option, etc. For example, a t-shirt available in different colors and/or sizes.', 'woocommerce' ),
					'i18n_product_other_tip'                          => __( 'Product types define available product details and attributes, such as downloadable files and variations. They’re also used for analytics and inventory management.', 'woocommerce' ),
					'i18n_product_description_tip'                    => __( 'Describe this product. What makes it unique? What are its most important features?', 'woocommerce' ),
					'i18n_product_short_description_tip'              => __( 'Summarize this product in 1-2 short sentences. We’ll show it at the top of the page.', 'woocommerce' ),
					'i18n_save_attribute_variation_tip'               => __( 'Make sure you enter the name and values for each attribute.', 'woocommerce' ),
					/* translators: %1$s: maximum file size */
					'i18n_product_image_tip'                          => sprintf( __( 'For best results, upload JPEG or PNG files that are 1000 by 1000 pixels or larger. Maximum upload file size: %1$s.', 'woocommerce' ), size_format( wp_max_upload_size() ) ),
					'i18n_remove_used_attribute_confirmation_message' => __( 'If you remove this attribute, customers will no longer be able to purchase some variations of this product.', 'woocommerce' ),
					'i18n_add_attribute_error_notice'                 => __( 'Adding new attribute failed.', 'woocommerce' ),
					/* translators: %s: WC_DELIMITER */
					'i18n_attributes_default_placeholder'             => sprintf( esc_attr__( 'Enter some descriptive text. Use “%s” to separate different values.', 'woocommerce' ), esc_attr( WC_DELIMITER ) ),
					'i18n_attributes_used_for_variations_placeholder' => sprintf( esc_attr__( 'Enter options for customers to choose from, f.e. “Blue” or “Large”. Use “%s” to separate different options.', 'woocommerce' ), esc_attr( WC_DELIMITER ) )
				);

				$cogs_controller = wc_get_container()->get( CostOfGoodsSoldController::class );
				if( $cogs_controller->feature_is_enabled() ) {
					$params['cogs_value_tooltip_simple_products'] = esc_attr( $cogs_controller->get_general_cost_edit_field_tooltip( false ) );
					$params['cogs_value_tooltip_variable_products'] = esc_attr( $cogs_controller->get_general_cost_edit_field_tooltip( true ) );
				}
				wp_localize_script( 'wc-admin-meta-boxes', 'woocommerce_admin_meta_boxes', $params );
			}

			// Term ordering - only when sorting by term_order.
			/* phpcs:disable WooCommerce.Commenting.CommentHooks.MissingHookComment */
			if ( ( strstr( $screen_id, 'edit-pa_' ) || ( ! empty( $_GET['taxonomy'] ) && in_array( wp_unslash( $_GET['taxonomy'] ), apply_filters( 'woocommerce_sortable_taxonomies', array( 'product_cat' ) ) ) ) ) && ! isset( $_GET['orderby'] ) ) {

				wp_register_script( 'woocommerce_term_ordering', WC()->plugin_url() . '/assets/js/admin/term-ordering' . $suffix . '.js', array( 'jquery-ui-sortable' ), $version );
				wp_enqueue_script( 'woocommerce_term_ordering' );

				$taxonomy = isset( $_GET['taxonomy'] ) ? wc_clean( wp_unslash( $_GET['taxonomy'] ) ) : '';

				$woocommerce_term_order_params = array(
					'taxonomy' => $taxonomy,
					'nonce'    => wp_create_nonce( 'term-ordering' ),
				);

				wp_localize_script( 'woocommerce_term_ordering', 'woocommerce_term_ordering_params', $woocommerce_term_order_params );
			}
			/* phpcs: enable */

			// Product sorting - only when sorting by menu order on the products page.
			if ( current_user_can( 'edit_others_pages' ) && 'edit-product' === $screen_id && isset( $wp_query->query['orderby'] ) && 'menu_order title' === $wp_query->query['orderby'] ) {
				wp_register_script( 'woocommerce_product_ordering', WC()->plugin_url() . '/assets/js/admin/product-ordering' . $suffix . '.js', array( 'jquery-ui-sortable' ), $version, true );
				wp_enqueue_script( 'woocommerce_product_ordering' );

				wp_localize_script(
					'woocommerce_product_ordering',
					'woocommerce_product_ordering_params',
					array( 'nonce' => wp_create_nonce( 'product-ordering' ) )
				);
			}

			// Reports Pages.
			/* phpcs:disable WooCommerce.Commenting.CommentHooks.MissingHookComment */
			if ( in_array( $screen_id, apply_filters( 'woocommerce_reports_screen_ids', array( $wc_screen_id . '_page_wc-reports', 'toplevel_page_wc-reports' ) ) ) ) {
				wp_register_script( 'wc-reports', WC()->plugin_url() . '/assets/js/admin/reports' . $suffix . '.js', array( 'jquery', 'jquery-ui-datepicker' ), $version );

				wp_enqueue_script( 'wc-reports' );
				wp_enqueue_script( 'wc-flot' );
				wp_enqueue_script( 'wc-flot-resize' );
				wp_enqueue_script( 'wc-flot-time' );
				wp_enqueue_script( 'wc-flot-pie' );
				wp_enqueue_script( 'wc-flot-stack' );
			}
			/* phpcs: enable */

			// API settings.
			if ( $wc_screen_id . '_page_wc-settings' === $screen_id && isset( $_GET['section'] ) && 'keys' == $_GET['section'] ) {
				wp_register_script( 'wc-api-keys', WC()->plugin_url() . '/assets/js/admin/api-keys' . $suffix . '.js', array( 'jquery', 'woocommerce_admin', 'underscore', 'backbone', 'wp-util', 'wc-qrcode', 'wc-clipboard' ), $version, true );
				wp_enqueue_script( 'wc-api-keys' );
				wp_localize_script(
					'wc-api-keys',
					'woocommerce_admin_api_keys',
					array(
						'ajax_url'         => admin_url( 'admin-ajax.php' ),
						'update_api_nonce' => wp_create_nonce( 'update-api-key' ),
						'clipboard_failed' => esc_html__( 'Copying to clipboard failed. Please press Ctrl/Cmd+C to copy.', 'woocommerce' ),
					)
				);
			}

			// Email settings.
			if ( $wc_screen_id . '_page_wc-settings' === $screen_id && isset( $_GET['tab'] ) && 'email' === $_GET['tab'] ) {
				wp_enqueue_media();
			}

			// System status.
			if ( $wc_screen_id . '_page_wc-status' === $screen_id ) {
				wp_register_script( 'wc-admin-system-status', WC()->plugin_url() . '/assets/js/admin/system-status' . $suffix . '.js', array( 'wc-clipboard' ), $version );
				wp_enqueue_script( 'wc-admin-system-status' );
				wp_localize_script(
					'wc-admin-system-status',
					'woocommerce_admin_system_status',
					array(
						'delete_log_confirmation' => esc_js( __( 'Are you sure you want to delete this log?', 'woocommerce' ) ),
						'run_tool_confirmation'   => esc_js( __( 'Are you sure you want to run this tool?', 'woocommerce' ) ),
						'tools_poll_interval'     => 10000,
						'tools_url'               => esc_url_raw( admin_url( 'admin.php?page=wc-status&tab=tools' ) ),
					)
				);
			}

			if ( in_array( $screen_id, array( 'user-edit', 'profile' ) ) ) {
				wp_register_script( 'wc-users', WC()->plugin_url() . '/assets/js/admin/users' . $suffix . '.js', array( 'jquery', 'wc-enhanced-select', 'selectWoo' ), $version, true );
				wp_enqueue_script( 'wc-users' );
				wp_localize_script(
					'wc-users',
					'wc_users_params',
					array(
						'countries'              => wp_json_encode(
							array_merge( WC()->countries->get_allowed_country_states(), WC()->countries->get_shipping_country_states() ),
							JSON_HEX_TAG | JSON_UNESCAPED_SLASHES
						),
						'i18n_select_state_text' => esc_attr__( 'Select an option&hellip;', 'woocommerce' ),
					)
				);
			}

			if ( WC_Marketplace_Suggestions::show_suggestions_for_screen( $screen_id ) ) {
				$active_plugin_slugs = array_map( 'dirname', get_option( 'active_plugins' ) );
				wp_register_script(
					'marketplace-suggestions',
					WC()->plugin_url() . '/assets/js/admin/marketplace-suggestions' . $suffix . '.js',
					array( 'jquery', 'underscore', 'wc-js-cookie' ),
					$version,
					true
				);
				wp_localize_script(
					'marketplace-suggestions',
					'marketplace_suggestions',
					array(
						'dismiss_suggestion_nonce' => wp_create_nonce( 'add_dismissed_marketplace_suggestion' ),
						'active_plugins'           => $active_plugin_slugs,
						'dismissed_suggestions'    => WC_Marketplace_Suggestions::get_dismissed_suggestions(),
						'suggestions_data'         => WC_Marketplace_Suggestions::get_suggestions_api_data(),
						'manage_suggestions_url'   => admin_url( 'admin.php?page=wc-settings&tab=advanced&section=woocommerce_com' ),
						'in_app_purchase_params'   => WC_Admin_Addons::get_in_app_purchase_url_params(),
						'admin_base_url'           => admin_url(),
						'i18n_marketplace_suggestions_default_cta'
							=> esc_html__( 'Learn More', 'woocommerce' ),
						'i18n_marketplace_suggestions_dismiss_tooltip'
							=> esc_attr__( 'Dismiss this suggestion', 'woocommerce' ),
						'i18n_marketplace_suggestions_manage_suggestions'
							=> esc_html__( 'Manage suggestions', 'woocommerce' ),
					)
				);
				wp_enqueue_script( 'marketplace-suggestions' );
			}

			// Marketplace promotions.
			if ( in_array( $screen_id, array( 'edit-shop_coupon', 'woocommerce_page_wc-admin' ), true ) ) {

				$promotions = WC_Admin_Marketplace_Promotions::get_active_promotions();

				if ( false === $promotions ) {
					return;
				}

				wp_add_inline_script(
					'wc-admin-app',
					'window.wcMarketplace = ' . wp_json_encode( array( 'promotions' => $promotions ), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ),
					'before'
				);
			}
		}

		/**
		 * Enqueue a script in WordPress admin.
		 * Similar to `WCAdminAssets::register_script()` but without enqueuing unnecessary dependencies.
		 *
		 * @return void
		 */
		private function enqueue_script( string $script_path_name, string $script_name ) {
			$script_assets_filename = WCAdminAssets::get_script_asset_filename( $script_path_name, $script_name );
			$script_assets          = require WC_ADMIN_ABSPATH . WC_ADMIN_DIST_JS_FOLDER .  $script_path_name . '/' . $script_assets_filename;

			wp_enqueue_script(
				'wc-admin-' . $script_name,
				WCAdminAssets::get_url( $script_path_name . '/' . $script_name, 'js' ),
				$script_assets['dependencies'],
				WCAdminAssets::get_file_version( 'js', $script_assets['version'] ),
				true
			);
		}

		/**
		 * Enqueue command palette assets.
		 *
		 * @return void
		 */
		public function enqueue_command_palette_assets() {
			$this->enqueue_script( 'wp-admin-scripts', 'command-palette' );

			$admin_features_disabled = apply_filters( 'woocommerce_admin_disabled', false );
			if ( ! $admin_features_disabled ) {
				$analytics_reports = Analytics::get_report_pages();
				if ( is_array( $analytics_reports ) && count( $analytics_reports ) > 0 ) {
					$formatted_analytics_reports = array_map( function( $report ) {
						if ( ! is_array( $report ) ) {
							return null;
						}
						$title = array_key_exists( 'title', $report ) ? $report['title'] : '';
						$path = array_key_exists( 'path', $report ) ? $report['path'] : '';
						if (
							is_string( $title ) && $title !== "" &&
							is_string( $path ) && $path !== ""
						) {
							return array(
								'title' => wp_strip_all_tags( $title ),
								'path' => $path,
							);
						}
						return null;
					}, $analytics_reports );
					$formatted_analytics_reports = array_filter( $formatted_analytics_reports, 'is_array' );

					$this->enqueue_script( 'wp-admin-scripts', 'command-palette-analytics' );
					wp_localize_script(
						'wc-admin-command-palette-analytics',
						'wcCommandPaletteAnalytics',
						array(
							'reports' => $formatted_analytics_reports,
						)
					);
				}
			}
		}

		/**
		 * Helper function to determine whether the current screen is an order edit screen.
		 *
		 * @param string $screen_id Screen ID.
		 *
		 * @return bool Whether the current screen is an order edit screen.
		 */
		private function is_order_meta_box_screen( $screen_id ) {
			$screen_id = str_replace( 'edit-', '', $screen_id );

			$types_with_metaboxes_screen_ids = array_filter(
				array_map(
					'wc_get_page_screen_id',
					wc_get_order_types( 'order-meta-boxes' )
				)
			);

			return in_array( $screen_id, $types_with_metaboxes_screen_ids, true );
		}

	}

endif;

return new WC_Admin_Assets();
